This assignment includes several files:

- readme.txt 		 This is this file.

- instructions.txt	 This containes detailed assignment instructions.

- background.txt 	 This is a (very) short story giving background and context
  			 for the assignment. This file is optional and you
  			 don't have to read it. It is just for fun.

- design_questions.txt   This contains the design questions that must be
  			 answered for the "design" portion of this assignment.

- experiments.cpp	 This is the driver program. This is where the main
  			 is. You shouldn't edit this file.

- testplant.cpp	 	 A simple test program that you can use to test your
  			 plant class (optional).

- testtree.cpp	 	 A simple test program that you can use to test your
  			 tree class (optional).
  			 
- expected.txt		 the expected results when you use familydata.txt.

- makefile		 a makefile that contains build and test targets (optional).

